from distutils.core import setup

setup(
				name= 'nester',
				version = '1.0.0',
				py_modules = ['nester'],
				author = 'grc',
				email = 'rongchaogao@gmail.com',
				url = 'http://',
				description = 'a simple module',
				)
