def print_lol(the_list,level):
		for each_list in the_list:
				if isinstance(each_list,list):
						print_lol(each_list,level+1)
				else:
						for num in range(level):
								print("\t",end='')
								print(each_list)
